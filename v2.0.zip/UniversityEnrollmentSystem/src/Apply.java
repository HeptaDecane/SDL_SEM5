public interface Apply {
    Applicant.Status hover();
    Applicant.Status apply();
    void setApplicationForm(ApplicationForm applicationForm);
}
